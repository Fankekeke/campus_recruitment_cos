import { IconDefinition } from '../types';
declare const QqOutline: IconDefinition;
export default QqOutline;

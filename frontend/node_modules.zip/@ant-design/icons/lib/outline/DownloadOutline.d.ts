import { IconDefinition } from '../types';
declare const DownloadOutline: IconDefinition;
export default DownloadOutline;

import { IconDefinition } from '../types';
declare const DisconnectOutline: IconDefinition;
export default DisconnectOutline;

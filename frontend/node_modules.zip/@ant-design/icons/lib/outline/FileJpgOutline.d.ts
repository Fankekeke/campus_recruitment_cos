import { IconDefinition } from '../types';
declare const FileJpgOutline: IconDefinition;
export default FileJpgOutline;

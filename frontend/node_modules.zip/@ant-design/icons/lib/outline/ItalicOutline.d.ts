import { IconDefinition } from '../types';
declare const ItalicOutline: IconDefinition;
export default ItalicOutline;

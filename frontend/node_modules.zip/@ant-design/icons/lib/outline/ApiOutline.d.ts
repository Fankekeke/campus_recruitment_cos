import { IconDefinition } from '../types';
declare const ApiOutline: IconDefinition;
export default ApiOutline;

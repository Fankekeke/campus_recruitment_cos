import { IconDefinition } from '../types';
declare const PoundOutline: IconDefinition;
export default PoundOutline;

import { IconDefinition } from '../types';
declare const FunnelPlotOutline: IconDefinition;
export default FunnelPlotOutline;

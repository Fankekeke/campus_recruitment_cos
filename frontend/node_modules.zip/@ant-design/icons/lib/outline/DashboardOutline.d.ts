import { IconDefinition } from '../types';
declare const DashboardOutline: IconDefinition;
export default DashboardOutline;

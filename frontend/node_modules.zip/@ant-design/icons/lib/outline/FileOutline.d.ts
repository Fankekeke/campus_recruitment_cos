import { IconDefinition } from '../types';
declare const FileOutline: IconDefinition;
export default FileOutline;

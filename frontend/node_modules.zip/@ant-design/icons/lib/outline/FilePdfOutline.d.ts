import { IconDefinition } from '../types';
declare const FilePdfOutline: IconDefinition;
export default FilePdfOutline;

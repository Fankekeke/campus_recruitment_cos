import { IconDefinition } from '../types';
declare const FileProtectOutline: IconDefinition;
export default FileProtectOutline;

import { IconDefinition } from '../types';
declare const CopyOutline: IconDefinition;
export default CopyOutline;

import { IconDefinition } from '../types';
declare const DesktopOutline: IconDefinition;
export default DesktopOutline;

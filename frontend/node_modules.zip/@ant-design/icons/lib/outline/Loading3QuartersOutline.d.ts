import { IconDefinition } from '../types';
declare const Loading3QuartersOutline: IconDefinition;
export default Loading3QuartersOutline;

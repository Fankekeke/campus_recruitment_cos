import { IconDefinition } from '../types';
declare const FileWordOutline: IconDefinition;
export default FileWordOutline;

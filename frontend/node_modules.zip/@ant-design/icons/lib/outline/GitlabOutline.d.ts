import { IconDefinition } from '../types';
declare const GitlabOutline: IconDefinition;
export default GitlabOutline;

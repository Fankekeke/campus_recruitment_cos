import { IconDefinition } from '../types';
declare const ReadOutline: IconDefinition;
export default ReadOutline;

import { IconDefinition } from '../types';
declare const AccountBookOutline: IconDefinition;
export default AccountBookOutline;

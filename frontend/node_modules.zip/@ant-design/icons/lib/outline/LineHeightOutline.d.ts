import { IconDefinition } from '../types';
declare const LineHeightOutline: IconDefinition;
export default LineHeightOutline;

import { IconDefinition } from '../types';
declare const BankOutline: IconDefinition;
export default BankOutline;

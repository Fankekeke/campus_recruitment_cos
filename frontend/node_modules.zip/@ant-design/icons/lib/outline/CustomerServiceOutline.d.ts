import { IconDefinition } from '../types';
declare const CustomerServiceOutline: IconDefinition;
export default CustomerServiceOutline;

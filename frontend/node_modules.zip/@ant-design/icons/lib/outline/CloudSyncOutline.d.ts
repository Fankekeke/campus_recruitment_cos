import { IconDefinition } from '../types';
declare const CloudSyncOutline: IconDefinition;
export default CloudSyncOutline;

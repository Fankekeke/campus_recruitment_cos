import { IconDefinition } from '../types';
declare const FileSyncOutline: IconDefinition;
export default FileSyncOutline;

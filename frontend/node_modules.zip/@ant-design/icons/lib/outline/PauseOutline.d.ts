import { IconDefinition } from '../types';
declare const PauseOutline: IconDefinition;
export default PauseOutline;

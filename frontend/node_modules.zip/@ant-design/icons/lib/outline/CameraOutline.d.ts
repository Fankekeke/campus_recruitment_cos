import { IconDefinition } from '../types';
declare const CameraOutline: IconDefinition;
export default CameraOutline;

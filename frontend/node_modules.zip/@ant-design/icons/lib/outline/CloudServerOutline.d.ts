import { IconDefinition } from '../types';
declare const CloudServerOutline: IconDefinition;
export default CloudServerOutline;

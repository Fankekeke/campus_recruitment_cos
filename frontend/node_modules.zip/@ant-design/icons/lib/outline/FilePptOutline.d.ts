import { IconDefinition } from '../types';
declare const FilePptOutline: IconDefinition;
export default FilePptOutline;

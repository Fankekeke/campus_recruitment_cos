import { IconDefinition } from '../types';
declare const HeatMapOutline: IconDefinition;
export default HeatMapOutline;

import { IconDefinition } from '../types';
declare const FundOutline: IconDefinition;
export default FundOutline;

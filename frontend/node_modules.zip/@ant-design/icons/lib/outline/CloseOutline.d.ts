import { IconDefinition } from '../types';
declare const CloseOutline: IconDefinition;
export default CloseOutline;

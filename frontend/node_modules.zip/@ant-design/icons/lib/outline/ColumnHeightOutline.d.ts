import { IconDefinition } from '../types';
declare const ColumnHeightOutline: IconDefinition;
export default ColumnHeightOutline;

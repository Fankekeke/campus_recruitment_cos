import { IconDefinition } from '../types';
declare const LockOutline: IconDefinition;
export default LockOutline;

import { IconDefinition } from '../types';
declare const IdcardOutline: IconDefinition;
export default IdcardOutline;

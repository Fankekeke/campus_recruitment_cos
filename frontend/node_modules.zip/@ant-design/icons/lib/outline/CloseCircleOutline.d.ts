import { IconDefinition } from '../types';
declare const CloseCircleOutline: IconDefinition;
export default CloseCircleOutline;

import { IconDefinition } from '../types';
declare const ExclamationOutline: IconDefinition;
export default ExclamationOutline;

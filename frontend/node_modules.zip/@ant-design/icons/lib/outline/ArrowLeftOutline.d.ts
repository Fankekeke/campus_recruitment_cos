import { IconDefinition } from '../types';
declare const ArrowLeftOutline: IconDefinition;
export default ArrowLeftOutline;

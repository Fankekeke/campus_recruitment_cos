import { IconDefinition } from '../types';
declare const LeftSquareOutline: IconDefinition;
export default LeftSquareOutline;

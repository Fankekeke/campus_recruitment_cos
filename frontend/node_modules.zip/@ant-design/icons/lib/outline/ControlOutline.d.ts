import { IconDefinition } from '../types';
declare const ControlOutline: IconDefinition;
export default ControlOutline;

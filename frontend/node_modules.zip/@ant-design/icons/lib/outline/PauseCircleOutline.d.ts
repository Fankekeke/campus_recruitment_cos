import { IconDefinition } from '../types';
declare const PauseCircleOutline: IconDefinition;
export default PauseCircleOutline;

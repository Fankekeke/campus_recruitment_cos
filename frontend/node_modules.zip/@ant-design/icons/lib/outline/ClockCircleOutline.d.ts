import { IconDefinition } from '../types';
declare const ClockCircleOutline: IconDefinition;
export default ClockCircleOutline;

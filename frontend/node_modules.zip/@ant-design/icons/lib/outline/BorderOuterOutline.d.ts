import { IconDefinition } from '../types';
declare const BorderOuterOutline: IconDefinition;
export default BorderOuterOutline;

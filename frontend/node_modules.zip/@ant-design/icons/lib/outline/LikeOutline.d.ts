import { IconDefinition } from '../types';
declare const LikeOutline: IconDefinition;
export default LikeOutline;

import { IconDefinition } from '../types';
declare const PlusOutline: IconDefinition;
export default PlusOutline;

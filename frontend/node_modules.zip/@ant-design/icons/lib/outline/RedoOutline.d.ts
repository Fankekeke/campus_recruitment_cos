import { IconDefinition } from '../types';
declare const RedoOutline: IconDefinition;
export default RedoOutline;

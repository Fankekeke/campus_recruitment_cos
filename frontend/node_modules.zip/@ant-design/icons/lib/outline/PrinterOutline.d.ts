import { IconDefinition } from '../types';
declare const PrinterOutline: IconDefinition;
export default PrinterOutline;

declare const _default: {
    fill: string[];
    outline: string[];
    twotone: string[];
};
export default _default;

import { IconDefinition } from '../types';
declare const CodeSandboxSquareFill: IconDefinition;
export default CodeSandboxSquareFill;

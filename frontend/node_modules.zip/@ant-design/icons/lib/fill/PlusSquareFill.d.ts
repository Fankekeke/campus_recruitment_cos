import { IconDefinition } from '../types';
declare const PlusSquareFill: IconDefinition;
export default PlusSquareFill;

import { IconDefinition } from '../types';
declare const CreditCardFill: IconDefinition;
export default CreditCardFill;

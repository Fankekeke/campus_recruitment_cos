import { IconDefinition } from '../types';
declare const CloudFill: IconDefinition;
export default CloudFill;

import { IconDefinition } from '../types';
declare const LockFill: IconDefinition;
export default LockFill;

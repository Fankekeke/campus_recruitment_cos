import { IconDefinition } from '../types';
declare const WeiboCircleFill: IconDefinition;
export default WeiboCircleFill;

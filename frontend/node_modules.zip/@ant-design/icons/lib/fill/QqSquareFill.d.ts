import { IconDefinition } from '../types';
declare const QqSquareFill: IconDefinition;
export default QqSquareFill;

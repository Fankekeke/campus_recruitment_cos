import { IconDefinition } from '../types';
declare const FileTextFill: IconDefinition;
export default FileTextFill;

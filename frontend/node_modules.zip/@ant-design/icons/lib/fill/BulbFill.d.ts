import { IconDefinition } from '../types';
declare const BulbFill: IconDefinition;
export default BulbFill;

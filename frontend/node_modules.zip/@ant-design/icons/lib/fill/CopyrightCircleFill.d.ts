import { IconDefinition } from '../types';
declare const CopyrightCircleFill: IconDefinition;
export default CopyrightCircleFill;

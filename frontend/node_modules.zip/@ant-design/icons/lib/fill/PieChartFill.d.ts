import { IconDefinition } from '../types';
declare const PieChartFill: IconDefinition;
export default PieChartFill;

import { IconDefinition } from '../types';
declare const CameraFill: IconDefinition;
export default CameraFill;

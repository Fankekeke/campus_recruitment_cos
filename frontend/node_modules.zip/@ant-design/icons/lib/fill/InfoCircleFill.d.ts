import { IconDefinition } from '../types';
declare const InfoCircleFill: IconDefinition;
export default InfoCircleFill;

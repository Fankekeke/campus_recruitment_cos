import { IconDefinition } from '../types';
declare const StepForwardFill: IconDefinition;
export default StepForwardFill;

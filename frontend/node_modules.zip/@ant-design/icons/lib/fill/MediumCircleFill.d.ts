import { IconDefinition } from '../types';
declare const MediumCircleFill: IconDefinition;
export default MediumCircleFill;

import { IconDefinition } from '../types';
declare const ReconciliationFill: IconDefinition;
export default ReconciliationFill;

import { IconDefinition } from '../types';
declare const ChromeFill: IconDefinition;
export default ChromeFill;

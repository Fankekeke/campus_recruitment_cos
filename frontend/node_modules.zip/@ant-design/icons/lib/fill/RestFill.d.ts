import { IconDefinition } from '../types';
declare const RestFill: IconDefinition;
export default RestFill;

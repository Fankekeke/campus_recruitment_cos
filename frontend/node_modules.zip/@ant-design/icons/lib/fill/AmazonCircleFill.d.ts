import { IconDefinition } from '../types';
declare const AmazonCircleFill: IconDefinition;
export default AmazonCircleFill;

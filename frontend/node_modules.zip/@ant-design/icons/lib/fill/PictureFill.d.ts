import { IconDefinition } from '../types';
declare const PictureFill: IconDefinition;
export default PictureFill;

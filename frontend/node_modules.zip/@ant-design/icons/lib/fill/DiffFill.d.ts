import { IconDefinition } from '../types';
declare const DiffFill: IconDefinition;
export default DiffFill;

import { IconDefinition } from '../types';
declare const InteractionFill: IconDefinition;
export default InteractionFill;

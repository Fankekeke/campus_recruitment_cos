import { IconDefinition } from '../types';
declare const BuildFill: IconDefinition;
export default BuildFill;

import { IconDefinition } from '../types';
declare const DingtalkCircleFill: IconDefinition;
export default DingtalkCircleFill;
